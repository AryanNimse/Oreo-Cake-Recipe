# You will need -
# oreo biscit (30 biscit)
# powdered sugar (2 spoon)
# baking soda(1 table spoon)
# milk(2 cups)
# bowl
# a microwave plate for the cake
# oil 
# madia or flour(atta)
# and lots of love