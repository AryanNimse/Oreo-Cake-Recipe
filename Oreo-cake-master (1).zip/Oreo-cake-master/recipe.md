# first grind the oreo biscit into fine powder 
# transfer it to a bowl and add powdered sugar and baking soda
# mix well
# then add milk slowly (add milk in certain interval of time(do not add too much milk at a time))
# mix well 
# the bater shoul be in running consistence
# take the plate in which you will prepare the cake at oven
# grease it with oil and flour or madia
# pre heat oven for 30 sec
# then dust out the extra flour or madia 
# then slowly transfer the bater to the bowl 
# tap it slowly so that there is no air bubbles
# then keep it at oven for 5 min at the mode of microwave
# then take it out and let cool and then turn the plate upside down and the cake comes out
# ready to serve the cake made by lots of love
# enjoy it